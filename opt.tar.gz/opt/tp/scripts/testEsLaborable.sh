#!/bin/bash

source esLaborable.sh

esFeriado "2023-10-16"
esFeriado "2023-08-21"
esFeriado "2023-11-27"
esFeriado "2023-11-06"
esFeriado "2023-01-01"
esFeriado "2023-12-25"

