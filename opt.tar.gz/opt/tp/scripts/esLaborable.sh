#!/bin/bash


esFeriado(){
	fecha=$1
	feriados=( "01-01" "03-24" "04-02" "05-01" "05-25" "07-09" "12-08" "12-25" )

	dia_semana=$(date -d "$fecha" +%u)
 	mes_dia=$(date -d "$fecha" +%m-%d)
	mes=$(date -d "$fecha" +%m)

       case "$mes" in
	# Feriado del 17 de agosto: tercer lunes de agosto
	"08")
		if [ "$(date -d "$fecha" +%u)" -eq 1 ] && [ "$(date -d "$fecha" +%d)" -gt 17 ]; then       	echo "La fecha "$fecha" no es laborable por que es el Feriado del 17 de agosto que se festeja el tercer lunes de el mes"
		return 1
	fi
	;;
	# Feriado del 12 de octubre: segundo lunes del mes 
	"10")
		feriado="2023-10-12"
	if [ "$(date -d "$feriado" +%u)" -eq 2 ] || [ "$(date -d "$feriado" +%u)" -eq 3 ]; then 
             	if [ "$(date -d "$fecha" +%u)" -eq 1 ] && [ "$(date -d "$fecha" +%d)" -gt 7  ]; then
		echo "la fecha "$fecha" es feriado por el 12 de octubre"
		return 1
		fi

	elif [ "$(date -d "$feriado" +%u)" -eq 4 ] || [ "$(date -d "$feriado" +%u)" -eq 5 ]; then
		if [ "$(date -d "$fecha" +%u)" -eq 1 ]&& [ "$(date -d "$fecha" +%d)" -gt 12 ]; then
			echo "La fecha "$fecha" es feriado por el 12 de octubre"
			return 1
		fi
	fi
	;;
	# Feriado del 20 de noviembre: cuarto lunes del mes
	"11")
	if [ "$(date -d "$fecha" +%u)" -eq 1 ] && [ "$(date -d "$fecha" +%d)" -gt 20 ]; then
	echo "La fecha "$fecha" no es laborable por que es el feriado del 20 de noviembre que se festeja el cuarto lunes de noviembre"
	return 1
	fi
	;;
esac

	if [ $dia_semana -eq 6 ] || [ $dia_semana -eq 7 ]; then
		echo "La fecha $fecha es un fin de semana, no es laborable."
		return 1
	fi
	for feriado in "${feriados[@]}"; do
		if [ "$mes_dia" == "$feriado" ]; then
			echo "La fecha $fecha es un feriado en Argentina: $feriado."
			return 1
		fi
	done
	echo "La fecha $fecha es laborable."
	return 0

}
