
if [ $# -ne 1 ]; then	
	echo "Uso: $0 <nombre_del_proceso>"
	exit 1
fi
proceso="$1"
if pgrep -x "$proceso" >/dev/null; then
	echo "El proceso $proceso se esta ejecutando" > /dev/null
else 
	email_asunto="Error: Proceso $proceso no esta en ejecucion"
	email_chat="El proceso $proceso no se esta ejecutando"
	echo "$email_chat" | mutt -s "$email_asunto" root
	
fi
