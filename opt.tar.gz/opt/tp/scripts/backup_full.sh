#!/bin/bash

origen="$1"
destino="$2"
fecha=$(date "+%Y%m%d")
nombre="$(basename $origen)"
#Con esta funcion mostrara la informacion de ayuda
mostrar_ayuda (){
echo "Backup_full funciona para crear el backup de un directorio y enviar ese backup a un directorio deseado para hacer un backup la sintaxis es backup_full.sh 'direcotrio origen' 'directorio destino'"
exit 1
}
enviarMail(){
asunto_mail="LOG BACKUP"
cuerpo_mail="$1"
echo "$cuerpo_mail" | mutt -s "$asunto_mail" root
}
enviar_log(){
tiempo=$(date "+%H:%M:%S")
local mensaje="$1"
	echo "$fecha / $tiempo / $mensaje" >> "/var/log/backup_full.log"
	enviarMail echo"$fecha / $tiempo / $mensaje"
}

#Con esto si ingresan bash backup_full.sh -h les mostrara la funcion mostrar_ayuda
while getopts ":h" opt; do
case $opt in
	h) mostrar_ayuda;;
	\?) echo "opcion invalida" >&2; exit 1;;
	esac
done
#Tenemos que verificar que todos los directorios seleccionados esten montados o existan
if df -h "$origen" | grep -q "^/dev/"; then
	echo "El directorio $origen esta montado"
else
	echo "El directorio $origen no esta montado"
	exit 1
fi
if df -h "$destino" | grep -q "^/dev/"; then
	echo "El directorio $detino esta montado"
else
	echo "El directorio $destino no esta montado"
	exit 1
fi

if [ ! -d "$origen"  ]; then
	echo "El directorio origen '$1' no existe"
	exit 1
fi

if [ ! -d "$origen" ]; then
	echo "El directorio destino '$2' no existe"
	exit 1
fi



tar czf "${destino}/${nombre}_bkp_${fecha}.tar" "$origen" && enviar_log "El backup fue exitoso" || enviar_log "Hubo un error al hacer el backup"
